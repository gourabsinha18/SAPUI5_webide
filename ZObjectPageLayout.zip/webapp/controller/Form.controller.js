sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox"
], function (Controller, JSONModel, MessageBox) {
	"use strict";

	return Controller.extend("com.objectpagelayout.ZObjectPageLayout.controller.Form", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.objectpagelayout.ZObjectPageLayout.view.Form
		 */
		onInit: function () {
			this.getOwnerComponent().getRouter().getRoute("RouteView2").attachMatched(this._onRouteMatched, this);
		},
		_onRouteMatched: function (ev) {
			var oargs = ev.getParameter("arguments"),
				oView = this.getView();
			if (oargs.F === "C") {
				this.saveflag = true;
				oView.setModel(new JSONModel({
					ID: oargs.ID,
					Name: "",
					//Title: "Create",
					Description: "",
					ReleaseDate: "",
					DiscontinuedDate: "",
					Price: ""
				}));

			} else {
				var opath = "/Products(" + oargs.ID + ")";
				this.updatepath = opath;
				this.saveflag = false;

				var oModel1 = this.getOwnerComponent().getModel();
				oModel1.read(opath, {

					async: false,

					success: function (oData, response) {
						//sap.m.MessageToast.show("Success");
						var JSNOModel = new JSONModel(oData);
						//JSNOModel.setProperty("/Title","Update");
						oView.setModel(JSNOModel);

					},
					failed: function (oData, response) {
						sap.m.MessageToast.show("Failed to get InputHelpValues from service!");

					}

				});
			}

		},
		onsave: function () {
			var that = this;
			var opath = "/Products";
			var oModel1 = this.getOwnerComponent().getModel();
			var obj = this.getView().getModel().getData();
			if (this.saveflag === true) {
				oModel1.create(opath, obj, {

					async: false,

					success: function (oData, response) {
						var bCompact = !!that.getView().$().closest(".sapUiSizeCompact").length;
						MessageBox.success(
							"New Entry Has Created", {
								styleClass: bCompact ? "sapUiSizeCompact" : "",
								actions: [MessageBox.Action.OK],
								emphasizedAction: MessageBox.Action.OK,
								onClose: function (sAction) {
									that.getOwnerComponent().getModel().refresh(true);
									that.onnavback();

								}
							}
						);

					},
					failed: function (oData, response) {
						sap.m.MessageToast.show("Failed to get InputHelpValues from service!");

					}

				});
			} else {
				oModel1.update(this.updatepath, obj, {

					async: false,

					success: function (oData, response) {
						var bCompact = !!that.getView().$().closest(".sapUiSizeCompact").length;
						MessageBox.success(
							"Updated", {
								styleClass: bCompact ? "sapUiSizeCompact" : "",
								actions: [MessageBox.Action.OK],
								emphasizedAction: MessageBox.Action.OK,
								onClose: function (sAction) {
									that.getOwnerComponent().getModel().refresh(true);
									that.onnavback();

								}
							}
						);

					},
					failed: function (oData, response) {
						sap.m.MessageToast.show("Failed to get InputHelpValues from service!");

					}

				});

			}

		},
		onnavback: function () {
			this.getOwnerComponent().getRouter().navTo("RouteView1");
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.objectpagelayout.ZObjectPageLayout.view.Form
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.objectpagelayout.ZObjectPageLayout.view.Form
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.objectpagelayout.ZObjectPageLayout.view.Form
		 */
		//	onExit: function() {
		//
		//	}

	});

});