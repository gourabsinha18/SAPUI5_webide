sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox"
], function (Controller, JSONModel, MessageBox) {
	"use strict";

	return Controller.extend("com.objectpagelayout.ZObjectPageLayout.controller.View1", {
		onInit: function () {

		},
		onselect: function (Ev) {
			this.selected = Ev.getSource().getParent().getActiveItem();
			this.selecteditem = Ev.getSource().getBindingContext().getObject();
		},
		onUpdate: function (ev) {
			// if(this.selected==="true"){
			// 	this._oPopoveru = sap.ui.xmlfragment("com.objectpagelayout.ZObjectPageLayout.view.Fragments.UpdatePopover", this);
			// this.getView().addDependent(this._oPopoveru);
			// this._oPopoveru.setModel(new JSONModel(this.selecteditem));
			// this._oPopoveru.openBy(ev.getSource());
			// }else{
			// 	sap.m.MessageToast.show("Please Select an Item from the List to Update");
			// }
			var olist = this.getView().byId("idProductsTable");
			if (olist.getMode() === "None") {

				MessageBox.information("Please Select an Item first from the List then Update", {
					actions: [MessageBox.Action.OK, MessageBox.Action.CLOSE],
					emphasizedAction: MessageBox.Action.OK,
					onClose: function (sAction) {
						sap.m.MessageToast.show("Action selected: " + sAction);
						olist.setMode("SingleSelectLeft");
					}
				});

			} else {
				var desc = olist.getSelectedItem().getDescription();
				this.onnavigate(desc, "U");
				olist.setMode("None");
			}

		},
		onCreate: function (Ev) {
			if (!this._oPopover) {
				this._oPopover = sap.ui.xmlfragment("com.objectpagelayout.ZObjectPageLayout.view.Fragments.Popover", this);
				this.getView().addDependent(this._oPopover);
				this._oPopover.setModel(new JSONModel({
					ID: ""
				}));
			}
			this._oPopover.openBy(Ev.getSource());

		},
		onDelete: function (Ev) {
			var olist = this.getView().byId("idProductsTable");
			if (olist.getMode() === "None") {

				MessageBox.information("Please Select an Item first to Delete", {
					actions: [MessageBox.Action.OK, MessageBox.Action.CLOSE],
					emphasizedAction: MessageBox.Action.OK,
					onClose: function (sAction) {
						sap.m.MessageToast.show("Action selected: " + sAction);
						olist.setMode("MultiSelect");
						//olist.setMode("SingleSelectLeft");
					}
				});

			} else {
				// var selectedarray=olist.getSelectedItems();
				// if (selectedarray && selectedarray.length){
				// 	selectedarray.map(function (oContext) {
				// 	return oContext.getBindingContext().getObject();
				// });	
				// }
				// selectedarray.forEach(multidelete);
				// multidelete: function(I){
				// 	I.getDescription();
				// }
				for (var i = 1; i < olist.getSelectedItems().length; i++){
				var ID = olist.getSelectedItems()[i].getDescription();
				this.onOdataDelete(ID);}
				olist.setMode("None");
			}

		},
		handleokButton: function () {
			var ID = this._oPopover.getModel().getProperty("/ID");
			this.onnavigate(ID, "C");
			this._oPopover.close();

		},
		handlecancelButton: function () {
			this._oPopover.close();

		},
		cancelButton: function () {
			this._oPopoveru.close();
		},
		onExit: function () {

		},
		onOdataDelete: function (ID) {
			var oModel = this.getView().getModel();

			oModel.remove("/Products(" + ID + ")", {
				method: "DELETE",
				success: function (data) {
					sap.m.MessageToast.show("Item Deleted");
				},
				error: function (e) {
					sap.m.MessageToast.show("error");
				}
			});
		},
		onnavigate: function (ID, flag) {
			this.getOwnerComponent().getRouter().navTo("RouteView2", {
				ID: ID,
				F: flag

			});

		}
	});
});