sap.ui.define([
	"com/objectpagelayout/ZObjectPageLayout/test/unit/controller/View1.controller"
], function () {
	"use strict";
});