function initModel() {
	var sUrl = "/oDataService/V2/(S(ggckv2urfs2xjimxohacw3sx))/OData/OData.svc/";
	var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
	sap.ui.getCore().setModel(oModel);
}