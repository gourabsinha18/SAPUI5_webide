sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("com.sf.ZSimpleForm.controller.Home", {
		onInit: function () {

		},
		onEdit: function () {
			this.byId("idsavebtn").setVisible(true);
			this.byId("idinput").setVisible(true);
			this.byId("nameText").setVisible(false);
			this.byId("idinput4").setVisible(true);
			this.byId("streettext").setVisible(false);
			this.byId("idinput2").setVisible(true);
			this.byId("citytext").setVisible(false);
			this.byId("idinput3").setVisible(true);
			this.byId("countryText").setVisible(false);
			this.byId("ideditbtn").setVisible(false);

		},
		onSave: function () {
			this.byId("nameText").setText(this.byId("idinput").getValue());
			this.byId("streettext").setText(this.byId("idinput2").getValue());
			this.byId("citytext").setText(this.byId("idinput3").getValue());
			this.byId("countryText").setText(this.byId("idinput4").getValue());
			this.byId("ideditbtn").setVisible(true);
			this.byId("idinput").setVisible(false);
			this.byId("idinput2").setVisible(false);
			this.byId("idinput3").setVisible(false);
			this.byId("idinput4").setVisible(false);
			this.byId("nameText").setVisible(true);
			this.byId("streettext").setVisible(true);
			this.byId("citytext").setVisible(true);
			this.byId("countryText").setVisible(true);
			this.byId("idsavebtn").setVisible(false);
		}

	});
});