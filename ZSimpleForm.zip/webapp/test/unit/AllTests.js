sap.ui.define([
	"com/sf/ZSimpleForm/test/unit/controller/Home.controller"
], function () {
	"use strict";
});