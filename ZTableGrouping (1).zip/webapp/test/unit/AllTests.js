sap.ui.define([
	"com/tablegrouping/ZTableGrouping/test/unit/controller/View1.controller"
], function () {
	"use strict";
});