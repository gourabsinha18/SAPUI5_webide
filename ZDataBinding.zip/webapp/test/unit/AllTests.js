sap.ui.define([
	"com/databinding/ZDataBinding/test/unit/controller/View1.controller"
], function () {
	"use strict";
});