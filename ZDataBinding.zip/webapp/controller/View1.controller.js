sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("com.databinding.ZDataBinding.controller.View1", {
		onInit: function () {

		},
		onEdit: function () {
			this.byId("idsavebtn").setVisible(true);
			this.byId("idinput").setVisible(true);
			this.byId("nameText").setVisible(false);
			this.byId("idinput4").setVisible(true);
			this.byId("streettext").setVisible(false);
			this.byId("idinput2").setVisible(true);
			this.byId("citytext").setVisible(false);
			this.byId("idinput3").setVisible(true);
			this.byId("countryText").setVisible(false);
			this.byId("ideditbtn").setVisible(false);

		},
		onSave: function () {
			var obj = {
				name: this.byId("idinput").getValue(),
				city: this.byId("idinput3").getValue(),
				street: this.byId("idinput2").getValue(),
				country: this.byId("idinput4").getValue()
			};
			var ajsonmodel = new sap.ui.model.json.JSONModel();
			ajsonmodel.setData(obj);
			this.byId("SimpleFormDisplay354").setModel(ajsonmodel);

			this.byId("ideditbtn").setVisible(true);
			this.byId("idinput").setVisible(false);
			this.byId("idinput2").setVisible(false);
			this.byId("idinput3").setVisible(false);
			this.byId("idinput4").setVisible(false);
			this.byId("nameText").setVisible(true);
			this.byId("streettext").setVisible(true);
			this.byId("citytext").setVisible(true);
			this.byId("countryText").setVisible(true);
			this.byId("idsavebtn").setVisible(false);
		}

	});
});