sap.ui.define([
	"com/masterdetail/ZMasterDetail/test/unit/controller/View1.controller"
], function () {
	"use strict";
});