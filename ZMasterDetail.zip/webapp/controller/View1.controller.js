sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/base/Log"
], function (Controller, Log) {
	"use strict";

	return Controller.extend("com.masterdetail.ZMasterDetail.controller.View1", {
		onInit: function () {

		},
		onSelectionChange: function(Ev){
			this.getSplitAppObj().to(this.createId("detailDetail"));
			var path=Ev.getParameter("listItem").getBindingContext().sPath.substr(9);
			var obj=Ev.getSource().getParent().getModel().getData().dataset[path];
			var data=new sap.ui.model.json.JSONModel(obj);
			this.getView().byId("SimpleForm").setModel(data);
			
		},
		rowclick: function (Ev) {
			this.getSplitAppObj().to(this.createId("detailDetail"));
			var obj=Ev.getSource().getBindingContext().getObject();
			var data=new sap.ui.model.json.JSONModel(obj);
			this.getView().byId("SimpleForm").setModel(data);
		},
		navtotable: function(){
			this.getSplitAppObj().backDetail();
		},
		getSplitAppObj: function () {
			var result = this.getView().byId("SplitAppDemo");
			if (!result) {
				Log.info("SplitApp object can't be found");
			}
			return result;
		}
	});
});