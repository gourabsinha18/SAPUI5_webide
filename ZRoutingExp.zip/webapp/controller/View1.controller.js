sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("com.routingexample.ZRoutingExp.controller.View1", {
		onInit: function () {

		},
		navto2nd: function(){
				this.getOwnerComponent().getRouter().navTo("RouteView2");
		},
		navto3rd: function(){
				this.getOwnerComponent().getRouter().navTo("RouteView3");
		}
	});
});