sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("com.routetable2form.ZRouteTable2Form.controller.Table", {
		onInit: function () {
			var omodel = this.getOwnerComponent().getModel("data");
			this.getView().byId("idProductsTable").setModel(omodel);
		},
		onselect: function (event) {

			var selectedrow = event.getSource().getBindingContext().getObject();
			var ajsonmodel = new sap.ui.model.json.JSONModel();
			ajsonmodel.setData(selectedrow);
			sap.ui.getCore().setModel(ajsonmodel,"headermodel");
			// var oTable = event.getSource().getBindingContext().getObject();
			// var selectedRow = [];
			// selectedRow.push(oTable);
			//var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			// oRouter.navTo("RouteInfo", {
			// 	selectedrow: JSON.stringify(selectedRow)
			// });
			// this.getOwnerComponent().getRouter().navTo("RouteInfo",
			// 	{row:oTable}
			// );

			this.getOwnerComponent().getRouter().navTo("RouteInfo");

		}
	});
});