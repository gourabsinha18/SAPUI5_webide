sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("com.routetable2form.ZRouteTable2Form.controller.Info", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.routetable2form.ZRouteTable2Form.view.Info
		 */
		onInit: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("RouteInfo").attachMatched(this._onRouteMatched, this);

		},
		_onRouteMatched: function (oEvent) {
			// var sObjectId = oEvent.getParameter("arguments").selectedrow;
			// var a = JSON.parse(sObjectId);
			// sap.m.MessageToast.show(a);
			var obj= sap.ui.getCore().getModel("headermodel").getData();
			this.getView().setModel(new sap.ui.model.json.JSONModel(obj));
		},
		navtotable: function () {
				this.getOwnerComponent().getRouter().navTo("RouteTable");
			}
			/**
			 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
			 * (NOT before the first rendering! onInit() is used for that one!).
			 * @memberOf com.routetable2form.ZRouteTable2Form.view.Info
			 */
			//	onBeforeRendering: function() {
			//
			//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.routetable2form.ZRouteTable2Form.view.Info
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.routetable2form.ZRouteTable2Form.view.Info
		 */
		//	onExit: function() {
		//
		//	}

	});

});