sap.ui.define([
	"com/routetable2form/ZRouteTable2Form/test/unit/controller/Table.controller"
], function () {
	"use strict";
});