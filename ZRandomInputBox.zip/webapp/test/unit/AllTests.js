sap.ui.define([
	"com/randomib/ZRandomInputBox/test/unit/controller/View1.controller"
], function () {
	"use strict";
});