sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("com.randomib.ZRandomInputBox.controller.View1", {
		onInit: function () {

		},
		onadd: function (oEv) {
			var oView = this.getView();
			var btn = oEv.getSource().getText();

			for (var x = 0; x < btn; x++) {
				var oBtn = new sap.m.Button({
					icon: "sap-icon://circle-task-2",
					width: "auto",
					type: "Emphasized"
				});
				oView.byId("Vbox").addItem(oBtn);
			}

		},
		onchange: function (oEvent) {
			this.getView().byId("idaddbtn").setText(oEvent.getSource().getValue());

		},
		onchange1: function (oEvent1) {
			this.getView().byId("idaddbtn1").setText(oEvent1.getSource().getValue());
		},
		ondel: function (oEv1) {

			var Btn = oEv1.getSource().getText();
			var oItems = this.getView().byId("Vbox").getItems();
			for (var x = 1; x <= Btn; x++) {
				this.getView().byId("Vbox").removeItem(oItems[oItems.length - x]);

			}

		}
	});
});