sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function (Controller,JSONModel) {
	"use strict";
	// fragments are light weight UI
	// fragments Do not have their own controller
	// fragments share the control oF their parent view Controller

	return Controller.extend("com.fragment.ZFragment.controller.Home", {
		onInit: function () {
			var omodel = this.getOwnerComponent().getModel("data");
			this.getView().setModel(omodel);

		}
	});
});