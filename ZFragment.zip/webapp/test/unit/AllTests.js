sap.ui.define([
	"com/fragment/ZFragment/test/unit/controller/Home.controller"
], function () {
	"use strict";
});