sap.ui.define([
	"com/tablebind2/ZTableBind2/test/unit/controller/table.controller"
], function () {
	"use strict";
});