sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("com.tablebind2.ZTableBind2.controller.table", {
		onInit: function () {
			
			
		},
		onLoad: function() {
			 var omodel=this.getOwnerComponent().getModel("data");
			 this.getView().byId("idProductsTable").setModel(omodel);
			// var collection = [{
			// 	name: "GOURAB",
			// 	city: "berhampore",
			// 	street: "nilmoni lane",
			// 	country: "india"
			// }, {
			// 	name: "sOURAv",
			// 	city: "howrah",
			// 	street: "n.b.lane",
			// 	country: "india"
			// }, {
			// 	name: "dip",
			// 	city: "berhampore",
			// 	street: "newyork lane",
			// 	country: "india"
			// }, {
			// 	name: "rony",
			// 	city: "berlin",
			// 	street: "harish chandra street ",
			// 	country: "india"
			// }];
			// var ajsonmodel = new sap.ui.model.json.JSONModel();
			// ajsonmodel.setData(collection);
			// this.byId("idProductsTable").setModel(ajsonmodel);
			
		},
		onClear: function(){
			var arr=[];
			var ajsonmodel = new sap.ui.model.json.JSONModel();
			ajsonmodel.setData(arr);
			this.byId("idProductsTable").setModel(ajsonmodel);
			
		}
		
		
		
		
		
	});
});