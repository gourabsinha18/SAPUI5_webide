sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("com.cardlivechange.ZCardLiveChange.controller.View1", {
		onInit: function () {

		},
		handleSelectionFinish: function (oEvent) {
			//var obj = this.getView().byId('mcbox').getSelectedItem().getText();
			var selectedItems = oEvent.getParameter("selectedItems");

			var arr = [];
			if (selectedItems && selectedItems.length) {
				arr.push(selectedItems.map(function (oContext) {
					return oContext.getBindingContext().getObject();
				}));
			}
			
			
			var json = new sap.ui.model.json.JSONModel();
			json.setData(arr[0]);
			this.getView().byId("idcard").setModel(json,"headermodel");

		}
	});
});