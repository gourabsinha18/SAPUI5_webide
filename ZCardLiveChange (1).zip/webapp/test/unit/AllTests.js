sap.ui.define([
	"com/cardlivechange/ZCardLiveChange/test/unit/controller/View1.controller"
], function () {
	"use strict";
});