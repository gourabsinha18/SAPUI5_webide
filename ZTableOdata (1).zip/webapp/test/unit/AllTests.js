sap.ui.define([
	"com/tableodata/ZTableOdata/test/unit/controller/View1.controller"
], function () {
	"use strict";
});