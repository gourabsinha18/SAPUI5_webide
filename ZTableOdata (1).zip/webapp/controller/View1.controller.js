sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function (Controller, JSONModel) {
	"use strict";

	return Controller.extend("com.tableodata.ZTableOdata.controller.View1", {
		onInit: function () {

		},
		Onpress: function () {
			var oTable = this.getView().byId("idProductsTable");
			oTable.setBusy(true);
			var oModel1 = this.getOwnerComponent().getModel();
			oModel1.read("/Products", {

				async: false,

				success: function (oData, response) {
					sap.m.MessageToast.show("Success");
					var JSNOModel = new JSONModel(oData);
					oTable.setModel(JSNOModel);
					oTable.setBusy(false);
				},
				failed: function (oData, response) {
					sap.m.MessageToast.show("Failed to get InputHelpValues from service!");

				}

			});

		},
		onCreateEntry: function () {
			var that = this;
			var oDialog = new sap.m.Dialog({
				title: "Create",
				beginButton: new sap.m.Button({
					text: "OK",
					type: sap.m.ButtonType.Emphasized,
					press: function (ev) {
						var oData = ev.getSource().getParent().getContent();
						that.onOkPress(oData);
					}
				}),
				endButton: new sap.m.Button({
					text: "Close",
					type: sap.m.ButtonType.Reject,
					press: function (ev) {
						ev.getSource().getParent().close();
						ev.getSource().getParent().destroy();
					}
				}),
				content: [new sap.m.Input("ID", {
						width: "auto",
						placeholder: "Enter ID"

					}), new sap.m.Input("Name", {
						width: "auto",
						placeholder: "Enter Name"
					}), new sap.m.Input("Description", {
						width: "auto",
						placeholder: "Enter Description"

					}), new sap.m.DatePicker("ReleaseDate", {
						placeholder: "Enter ReleaseDate"
					}), new sap.m.DatePicker("DiscontinuedDate", {
						placeholder: "Enter DiscontinuedDate"
					}), new sap.m.Input("Rating", {
						width: "auto",
						placeholder: "Enter Rating"
					}),
					new sap.m.Input("Price", {
						width: "auto",
						placeholder: "Enter Price"
					})
				]
			});
			// var oInputid = new sap.m.Input();
			// var oInputname = new sap.m.Input();
			// var oInputdesc = new sap.m.Input();
			// var oInputreldt = new sap.m.DatePicker();
			// var oInputdscdate = new sap.m.DatePicker();
			// var oInputrating = new sap.m.Input();
			// var oInputprice = new sap.m.Input();
			// oDialog.addContent(oInputid);
			// oDialog.addContent(oInputname);
			// oDialog.addContent(oInputid);
			// oDialog.addContent(oInputid);
			// oDialog.addContent(oInputid);
			// oDialog.addContent(oInputid);
			oDialog.open();

		},
		onOkPress: function (data) {
			for (var i = 0; i < data.length; i++) {
				var obj = {
					//data[i].sId:data[i].getValue()
				};
			}
		},
		onClose1: function (ev) {
			ev.getSource().getParent().close();
			ev.getSource().getParent().destroy();

		},
		OnFragment: function () {

			if (!this.oAcademicFrag) {

				this.oAcademicFrag = sap.ui.xmlfragment(this.getView().getId(), "com.tableodata.ZTableOdata.view.Create", this);
				this.getView().addDependent(this.oAcademicFrag);
			}

			this.oAcademicFrag.open();

		},

		onClose: function () {

			this.oAcademicFrag.close();
		},
		onOK: function () {

		//	this.oPersonalDetails = sap.ui.xmlfragment(this.getView().getId(), "com.fragment.ZSAPUIFragment.view.Fragments.PersonalDetails", this);
		//	this.getView().addDependent(this.oPersonalDetails);
			var obj={
				"ID":this.getView().byId("ID").getValue(),
				"Name":this.getView().byId("Name").getValue(),
				"Description":this.getView().byId("Description").getValue(),
				"DiscontinuedDate":this.getView().byId("DP2").getValue(),
				"ReleaseDate":this.getView().byId("DP1").getValue(),
				"Rating":this.getView().byId("Rating").getValue(),
				"Price":this.getView().byId("Price").getValue()
				
			};
				var that=this;
			this.getOwnerComponent().getModel().create("/Products", obj, {
				success: function (odata, Response) {
					that.Onpress();
					sap.m.MessageToast.show("Success");
				},
				error: function (cc, vv) {
				sap.m.MessageToast.show("Error");
				}
			});
		this.oAcademicFrag.close();	
		}

	});
});