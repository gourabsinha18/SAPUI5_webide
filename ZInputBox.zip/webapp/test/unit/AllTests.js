sap.ui.define([
	"com/inputbox/ZInputBox/test/unit/controller/Home.controller"
], function () {
	"use strict";
});