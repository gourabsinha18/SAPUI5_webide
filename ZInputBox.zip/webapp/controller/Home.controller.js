sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("com.inputbox.ZInputBox.controller.Home", {
		onInit: function () {

		},
		onpressadd: function () {

			var oLabel = new sap.m.Label({
				text: "LABEL",
				labelfor: "oInput",
				design: "Bold"
			});
			var oView = this.getView();
			var oInput = new sap.m.Input({
				placeholder: "type something",
				width: "auto",
				type: "Text"
			});
			oView.byId("Vbox").addItem(oLabel);
			oView.byId("Vbox").addItem(oInput);

			// var oContent = oView.getContent()[0].getApp().getPages()[0].getContent()[1];
			// oContent.addItem(oLabel);
		},
		onpressdel: function () {
			var oItems = this.getView().byId("Vbox").getItems();
			this.getView().byId("Vbox").removeItem(oItems[oItems.length - 1]);
			this.getView().byId("Vbox").removeItem(oItems[oItems.length - 2]);

		}

	});
});