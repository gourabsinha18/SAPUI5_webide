sap.ui.define([
	"com/odatanav/ZOdataNav/test/unit/controller/View1.controller"
], function () {
	"use strict";
});