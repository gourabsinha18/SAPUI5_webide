sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function (Controller, JSONModel) {
	"use strict";

	return Controller.extend("com.odatanav.ZOdataNav.controller.Details", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.odatanav.ZOdataNav.view.Details
		 */
		onInit: function () {
			this.getOwnerComponent().getRouter().getRoute("RouteView2").attachMatched(this._onRouteMatched, this);
		},
		_onRouteMatched: function (ev) {
			this.oArgs = ev.getParameter("arguments").ID;
			this.getView().getContent()[0].getPages()[0].setTitle("Navigation Properties based on ProductID :" + this.oArgs);
			this.ondataread();
			this.onTabChange();

		},
		ondataread: function (ID) {
			if (ID === undefined) {
				var opath = "/Products(" + this.oArgs + ")";
				var oItem = this.getView().byId("SimpleForm");
			}

			var oModel1 = this.getOwnerComponent().getModel();
			oModel1.read(opath, {

				async: false,

				success: function (oData, response) {
					sap.m.MessageToast.show("Success");
					var JSNOModel = new JSONModel();

					if (ID !== undefined) {
						// var arr = [];
						// arr.push(oData);
						JSNOModel.setData(oData);
					} else {
						JSNOModel.setData(oData);
					}

					oItem.setModel(JSNOModel);
					oItem.setBusy(false);
				},
				failed: function (oData, response) {
					sap.m.MessageToast.show("Failed to get InputHelpValues from service!");

				}

			});

		},
		onTabChange: function (ev) {
			var key = "Order";
			if (ev !== undefined) {
				key = ev.getSource().getSelectedKey();
				var itbfcount = ev.getParameters().selectedItem;
			} else {
				itbfcount = this.getView().byId("idIconTabBar").getAggregation("_header").oSelectedItem;
			}
			if (key === "Order") {
				var oPath = "/Products(" + this.oArgs + ")/Order_Details";
				this.oEntity = "Order_Details";
				this.onTabBind(oPath, itbfcount);
			} else if (key === "Cat") {
				oPath = "/Products(" + this.oArgs + ")/Category";
				this.onTabBind(oPath, itbfcount);
				this.oEntity = "Category";
			} else {
				oPath = "/Products(" + this.oArgs + ")/Supplier";
				this.onTabBind(oPath, itbfcount);
				this.oEntity = "Suppliers";
			}
		},
		onTabBind: function (opath, count) {
			var that = this;
			var oModel1 = this.getOwnerComponent().getModel();
			var JSONModel1 = new JSONModel();
			oModel1.read(opath, {

				async: false,

				success: function (oData, response) {
					sap.m.MessageToast.show("Success");
					if (oData.results && oData.results.length) {
						count.setCount(oData.results.length);
						JSONModel1.setData(oData);
						that.getView().setModel(JSONModel1, "TabModel");

					} else {
						var arr = [];
						arr.push(oData);
						count.setCount(arr.length);
						JSONModel1.setData({
							results: arr
						});
						that.getView().setModel(JSONModel1, "TabModel");
					}

					// if (ID !== undefined) {
					// 	var arr = [];
					// 	arr.push(oData);
					// 	JSNOModel.setData(arr);
					// } else {
					// 	JSNOModel.setData(oData);
					// }

					// oItem.setModel(JSNOModel);
					// oItem.setBusy(false);
				},
				failed: function (oData, response) {
					sap.m.MessageToast.show("Failed to get InputHelpValues from service!");

				}

			});
		},
		onpressinfo: function (ev) {
			var oCtx = ev.getSource().getBindingContext("TabModel");
			if (this.oEntity === "Order_Details") {
				
				this.oEntity=this.oEntity+"(OrderID="+oCtx.getProperty("OrderID")+",ProductID="+oCtx.getProperty("ProductID")+")";
				var flag="O";
				
			}
			if (this.oEntity === "Category") {
				this.oEntity=this.oEntity+"("+oCtx.getProperty("CategoryID")+")";
				flag="C";
			}
			if (this.oEntity === "Suppliers") {
				
				this.oEntity=this.oEntity+"("+oCtx.getProperty("SupplierID")+")";
				flag="S";
					
			
			}
			this.getOwnerComponent().getRouter().navTo("RouteView3", {
				flag:flag,
				entity: this.oEntity
				

					
			});
			

		},
		onNavpress: function () {
				this.getView().byId("idIconTabBar").setSelectedKey("Order");
				this.getOwnerComponent().getRouter().navTo("RouteView1");
			}
			/**
			 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
			 * (NOT before the first rendering! onInit() is used for that one!).
			 * @memberOf com.odatanav.ZOdataNav.view.Details
			 */
			//	onBeforeRendering: function() {
			//
			//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.odatanav.ZOdataNav.view.Details
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.odatanav.ZOdataNav.view.Details
		 */
		//	onExit: function() {
		//
		//	}

	});

});