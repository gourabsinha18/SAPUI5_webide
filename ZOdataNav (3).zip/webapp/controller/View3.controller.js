sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("com.odatanav.ZOdataNav.controller.View3", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.odatanav.ZOdataNav.view.View3
		 */
		onInit: function () {
			this.getOwnerComponent().getRouter().getRoute("RouteView3").attachMatched(this._onRouteMatched, this);
		},
		_onRouteMatched: function (ev) {
			var oArgs = ev.getParameter("arguments"),
				oView = this.getView();

			this.getView().bindElement({
				path: "/" + oArgs.entity,
				datarequested: function (oR) {
					oView.setBusy(true);

				},
				datareceived: function (oR) {
					oView.setBusy(false);

				}

			});
			if (oArgs.flag === "O") {
				//this.onreadorder();
				this.getView().byId("idform1").setVisible(true);
				this.getView().byId("idform2").setVisible(false);
				this.getView().byId("idform3").setVisible(false);

			}
			if (oArgs.flag === "S") {
				//this.onreadsupplier();
					this.getView().byId("idform1").setVisible(false);
				this.getView().byId("idform2").setVisible(true);
				this.getView().byId("idform3").setVisible(false);

			}
			if (oArgs.flag === "C") {
				//this.ondataread();
				this.getView().byId("idform1").setVisible(false);
				this.getView().byId("idform2").setVisible(false);
				this.getView().byId("idform3").setVisible(true);
			}

		},
		onreadorder: function (ID) {
			if (ID === undefined) {
				var opath = "/Order_Details(OrderID=" + this.oArgs.oProp + ",ProductID=" + this.oArgs.oProdid +
					")/Order";
				//console.log(oPath);

				var oItem = this.getView().byId("idform1");
			}

			var oModel1 = this.getOwnerComponent().getModel();
			oModel1.read(opath, {

				async: false,

				success: function (oData, response) {
					sap.m.MessageToast.show("Success");
					var JSNOModel = new sap.ui.model.json.JSONModel();

					if (ID !== undefined) {
						// var arr = [];
						// arr.push(oData);
						JSNOModel.setData(oData);
					} else {
						JSNOModel.setData(oData);
					}

					oItem.setModel(JSNOModel);
					oItem.setBusy(false);
				},
				failed: function (oData, response) {
					sap.m.MessageToast.show("Failed to get InputHelpValues from service!");

				}

			});

		},
		onreadsupplier: function (ID) {
			if (ID === undefined) {
				var opath = "Suppliers(" + this.oArgs.oSupId + ")/Products ";
				//console.log(oPath);

				var oItem = this.getView().byId("idform2");
			}

			var oModel1 = this.getOwnerComponent().getModel();
			oModel1.read(opath, {

				async: false,

				success: function (oData, response) {
					sap.m.MessageToast.show("Success");
					var JSNOModel = new sap.ui.model.json.JSONModel();

					if (ID !== undefined) {
						// var arr = [];
						// arr.push(oData);
						JSNOModel.setData(oData);
					} else {
						JSNOModel.setData(oData);
					}

					oItem.setModel(JSNOModel);
					oItem.setBusy(false);
				},
				failed: function (oData, response) {
					sap.m.MessageToast.show("Failed to get InputHelpValues from service!");

				}

			});

		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.odatanav.ZOdataNav.view.View3
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.odatanav.ZOdataNav.view.View3
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.odatanav.ZOdataNav.view.View3
		 */
		//	onExit: function() {
		//
		//	}

	});

});