sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function (Controller, JSONModel) {
	"use strict";

	return Controller.extend("com.odatanav.ZOdataNav.controller.View1", {
		onInit: function () {
			this.arr = [];
			this.ondataread();
		},
		ondataread: function (ID) {
			if (ID === undefined) {
				var oItem = this.getView().byId("idCB");
				var opath = "/Products";

			} else {
				oItem = this.getView().byId("idlist");
				opath = "/Products(" + ID + ")";
			}

			oItem.setBusy(true);
			//var that=this;
			var oModel1 = this.getOwnerComponent().getModel();
			oModel1.read(opath, {

				async: false,

				success: function (oData, response) {
					sap.m.MessageToast.show("Success");
					var JSNOModel = new JSONModel();

					if (ID !== undefined) {
						var arr = [];
						arr.push(oData);
						JSNOModel.setData(arr);
					} else {
						JSNOModel.setData(oData);
					}

					oItem.setModel(JSNOModel);
					oItem.setBusy(false);
				},
				failed: function (oData, response) {
					sap.m.MessageToast.show("Failed to get InputHelpValues from service!");

				}

			});

		},
		onchange: function (Ev) {
			var oid = Ev.getSource().getSelectedKey();
			this.ondataread(oid);

		},
		onListItemPress: function (ev) {
			this.getOwnerComponent().getRouter().navTo("RouteView2", {
				ID: ev.getSource().getBindingContext().getProperty("ProductID")
			});
		}

	});
});