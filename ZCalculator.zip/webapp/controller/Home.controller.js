sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("com.calculator.ZCalculator.controller.Home", {
		onInit: function () {

		},
		onpress: function(oEvent){
			var a=parseInt(this.getView().byId("idinput1").getValue());
			var b=parseInt(this.getView().byId("idinput2").getValue());
			var oBtntxt=oEvent.getSource().getText();
			var result;
			if(oBtntxt==="+"){
				result=a+b;
			}
			if(oBtntxt==="-"){
				result=a-b;
			}
			if(oBtntxt==="*"){
				result=a*b;
			}
			if(oBtntxt==="/"){
				result=a/b;
			}
			sap.m.MessageToast.show("result is:"+" "+result);
			
		}
		
		
		
		
		
		
		
		
		
		
		
		
	});
});