sap.ui.define([
	"com/calculator/ZCalculator/test/unit/controller/Home.controller"
], function () {
	"use strict";
});