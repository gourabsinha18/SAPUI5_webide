sap.ui.define([
	"com/vhm/ZValueHelpModel/test/unit/controller/View1.controller"
], function () {
	"use strict";
});