sap.ui.define([
	"sap/ui/core/mvc/Controller",
	'sap/ui/model/Filter',
	'sap/ui/model/FilterOperator',
	'sap/ui/model/json/JSONModel'
], function (Controller, Filter, FilterOperator, JSONModel) {
	"use strict";

	return Controller.extend("com.vhm.ZValueHelpModel.controller.View1", {
		onInit: function () {

			// this.emp = [{
			// 	fname: "Anubhav",
			// 	lname: "Mitra",
			// 	empId: "123456",
			// 	city: "Kolkata",
			// 	country: "India",
			// 	department: "UI5"

			// }, {
			// 	fname: "Ishan",
			// 	lname: "Ghosh",
			// 	empId: "23456",
			// 	city: "Kolkata",
			// 	country: "Australia",
			// 	department: "UI5"

			// }, {
			// 	fname: "Partha",
			// 	lname: "Chatterjee",
			// 	empId: "789456",
			// 	city: "Howrah",
			// 	country: "Canada",
			// 	department: "UI5"

			// }, {
			// 	fname: "Souvik",
			// 	lname: "Ghosh",
			// 	empId: "47185",
			// 	city: "Bally",
			// 	country: "Spain",
			// 	department: "Fiori"

			// }, {
			// 	fname: "Ankit",
			// 	lname: "Sen",
			// 	empId: "258634",
			// 	city: "Salkia",
			// 	country: "Japan",
			// 	department: "B1"

			// }, {
			// 	fname: "Abinash",
			// 	lname: "Maity",
			// 	empId: "965847",
			// 	city: "Salkia",
			// 	country: "Hongkong",
			// 	department: "Fiori"
			// }];

			//	this.getView().setModel(oModel);
		},
		handleValueHelpemp: function (oController) {
			/*	this.inputId = oController.getSource().getId();*/
			// create value help dialog
			if (!this.oEmployeeFrag) {
				this.oEmployeeFrag = sap.ui.xmlfragment(this.getView().getId(), "com.vhm.ZValueHelpModel.view.Fragments.Employee",
					this);
				this.getView().addDependent(this.oEmployeeFrag);

			}
			var oModel = this.getOwnerComponent().getModel("employeee").getData().employee;
			this.oEmployeeFrag.setModel(new JSONModel(oModel));
			this.oEmployeeFrag.open();

		},

		/*	onClose: function () {

				this.oEmployeeFrag.close();
			},*/
		_handleValueHelpempClose: function (evt) {

			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId("InputValueHelp");
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		},

		_handleValueHelpempSearch: function (evt) {

			/*	var sFilter;
				var query = evt.getParameter("value");
				if (query && query.length > 0) {
					
						sFilter = new sap.ui.model.Filter("fname", sap.ui.model.FilterOperator.Contains, query);
					
					var	sFilter1 = new sap.ui.model.Filter("lname", sap.ui.model.FilterOperator.Contains, query);
				var oFilters = new sap.ui.model.Filter({ filters: [ sFilter, sFilter1 ], and: false });

					
				}*/

			//evt.getSource().getBinding("items").filter(oFilters);

			////////////////////////////////////////////////////////		
			var sValue = evt.getParameter("value");

			var oFilters = new Filter({
				filters: [new Filter(
					"fname",
					FilterOperator.Contains, sValue
				), new Filter(
					"lname",
					FilterOperator.Contains, sValue
				)],
				and: false
			});

			evt.getSource().getBinding("items").filter([oFilters]);
		},

		handleValueHelpempId: function (oController) {

			if (!this.oEmpIdFrag) {
				this.oEmpIdFrag = sap.ui.xmlfragment(this.getView().getId(), "com.vhm.ZValueHelpModel.view.Fragments.EmpID",
					this);
				this.getView().addDependent(this.oEmpIdFrag);
			}

			var oModel = this.getOwnerComponent().getModel("empId").getData().empId;
			this.oEmpIdFrag.setModel(new JSONModel(oModel));
			this.oEmpIdFrag.open();

		},

		_handleValueHelpempIdClose: function (evt) {

			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId("InputValueHelp1");
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		},

		_handleValueHelpempIdSearch: function (evt) {

			var sValue = evt.getParameter("value");

			var oFilters = new Filter({
				filters: [new Filter(
					"empId",
					FilterOperator.Contains, sValue
				)],
				and: false
			});

			evt.getSource().getBinding("items").filter([oFilters]);
		},

		handleValueHelpcity: function (oController) {
			if (!this.oCityFrag) {
				this.oCityFrag = sap.ui.xmlfragment(this.getView().getId(), "com.vhm.ZValueHelpModel.view.Fragments.City",
					this);
				this.getView().addDependent(this.oCityFrag);

			}

			var oModel = this.getOwnerComponent().getModel("empcity").getData().city;
			this.oCityFrag.setModel(new JSONModel(oModel));
			this.oCityFrag.open();

		},

		_handleValueHelpcityClose: function (evt) {

			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId("InputValueHelp2");
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		},

		_handleValueHelpcitySearch: function (evt) {

			var sValue = evt.getParameter("value");

			var oFilters = new Filter({
				filters: [new Filter(
					"city",
					FilterOperator.Contains, sValue
				)],
				and: false
			});

			evt.getSource().getBinding("items").filter([oFilters]);
		},
		handleValueHelpcountry: function (oController) {
			if (!this.oCountryFrag) {
				this.oCountryFrag = sap.ui.xmlfragment(this.getView().getId(), "com.vhm.ZValueHelpModel.view.Fragments.Country",
					this);
				this.getView().addDependent(this.oCountryFrag);
			}

			var oModel = this.getOwnerComponent().getModel("empcountry").getData().country;
			this.oCountryFrag.setModel(new JSONModel(oModel));
			this.oCountryFrag.open();

		},

		_handleValueHelpcountryClose: function (evt) {

			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId("InputValueHelp3");
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		},

		_handleValueHelpcountrySearch: function (evt) {

			var sValue = evt.getParameter("value");

			var oFilters = new Filter({
				filters: [new Filter(
					"country",
					FilterOperator.Contains, sValue
				)],
				and: false
			});

			evt.getSource().getBinding("items").filter([oFilters]);
		},
		handleValueHelpdepartment: function (oController) {
			if (!this.oDepartmentFrag) {
				this.oDepartmentFrag = sap.ui.xmlfragment(this.getView().getId(),
					"com.vhm.ZValueHelpModel.view.Fragments.Department",
					this);
				this.getView().addDependent(this.oDepartmentFrag);
			}

			var oModel = this.getOwnerComponent().getModel("empdept").getData().department;
			this.oDepartmentFrag.setModel(new JSONModel(oModel));
			this.oDepartmentFrag.open();

		},

		_handleValueHelpdepartmentClose: function (evt) {

			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId("InputValueHelp4");
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		},

		_handleValueHelpdepartmentSearch: function (evt) {

			var sValue = evt.getParameter("value");

			var oFilters = new Filter({
				filters: [new Filter(
					"department",
					FilterOperator.Contains, sValue
				)],
				and: false
			});

			evt.getSource().getBinding("items").filter([oFilters]);
		},
		OnPress: function () {
			var oView = this.getView();
			if (oView.byId("InputValueHelp").getValue()=== ""){
				oView.byId("InputValueHelp").setValueState(sap.ui.core.ValueState.Error);
				sap.m.MessageToast.show("Please Enter all the Fields");
			}

		}

	});
});