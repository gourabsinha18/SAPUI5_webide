sap.ui.define([
	"com/fragment1/ZFragment1/test/unit/controller/View1.controller"
], function () {
	"use strict";
});