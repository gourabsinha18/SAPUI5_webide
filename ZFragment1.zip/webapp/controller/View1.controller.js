sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/ValueState"
], function (Controller, ValueState) {
	"use strict";

	return Controller.extend("com.fragment1.ZFragment1.controller.View1", {
		onInit: function () {

		},
		onopendialog: function () {
			// if(!this.opersonalfrag){
			// this.opersonalfrag=sap.ui.xmlfragment( "com.fragment1.ZFragment1.view.Fragments.personalinfo" ,this);

			this.getView().addDependent(this.opersonalfrag);
			// }

			// this.opersonalfrag.open();
			var opersonalfrag = sap.ui.xmlfragment("com.fragment1.ZFragment1.view.Fragments.personalinfo", this);
			opersonalfrag.open();
		},
		onopenAcademy: function () {

			var opersonalfrag = sap.ui.xmlfragment("com.fragment1.ZFragment1.view.Fragments.academicinfo", this);
			this.getView().addDependent(this.opersonalfrag);
			opersonalfrag.open();

		},
		onokpress: function (Ev) {
			var oCore = sap.ui.getCore();
			var obj = {
				name: oCore.byId("idname").getValue(),
				city: oCore.byId("idcity").getValue(),
				street: oCore.byId("idstreet").getValue(),
				country: oCore.byId("idcountry").getValue()
			};
			var ajsonmodel = new sap.ui.model.json.JSONModel();
			ajsonmodel.setData(obj);
			if (oCore.byId("idname").getValue() === "") {
				oCore.byId("idname").setValueState(ValueState.Error);
			} else {
				this.byId("SimpleFormDisplay354").setModel(ajsonmodel);

				this.byId("SimpleFormDisplay354").setVisible(true);

				Ev.getSource().getParent().close();
				Ev.getSource().getParent().destroy();
			}

		},
		// onLiveChange: function (oEvent) {
		// 	var newValue = oEvent.getParameter("newValue");
		// 	this.setValueState(sap.ui.core.ValueState.Success); //you can also use None, or just remove this line

		// 	if ( newValue==""  )
		// 		{this.setValueState(sap.ui.core.ValueState.Error)};
		// },
		onLiveChange: function (Ev) {

			// this function gets the first textfield

			//this function checks its value, you can insert more checks on the value
			if (Ev.getParameter("value") !== "") {
				Ev.getSource().setValueState(ValueState.None);
			}

			// ...
			// the same for the other fields
		},

		onokacademy: function (Ev) {
			var obj = {
				LastQualification: sap.ui.getCore().byId("idlq").getValue(),
				Board: sap.ui.getCore().byId("idboard").getValue(),
				Percent: sap.ui.getCore().byId("idpercent").getValue(),
				Grade: sap.ui.getCore().byId("idgrade").getValue()
			};
			var ajsonmodel = new sap.ui.model.json.JSONModel();
			ajsonmodel.setData(obj);
			this.byId("SimpleFormDisplay35").setModel(ajsonmodel);

			this.byId("SimpleFormDisplay35").setVisible(true);

			Ev.getSource().getParent().close();
			Ev.getSource().getParent().destroy();

		},
		onclosepress: function (Ev) {
			//this.opersonalfrag.close();
			Ev.getSource().getParent().close();
			Ev.getSource().getParent().destroy();
		}

	});
});