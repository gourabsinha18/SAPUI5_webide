sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/Fragment",
	"sap/ui/model/json/JSONModel"
], function (Controller, Fragment, JSONModel) {
	"use strict";

	return Controller.extend("com.tabletopopover.ZTabletoPopover.controller.Home", {
		onInit: function () {
			// var oLabel = this.getView().byId("oLabel");
			// var result = this.GetClock();
			// oLabel.setText(result);
			var that = this;
			setInterval(function () {
				//var result = that.GetClock1();
				that.GetClock1();
				
				//oLabel.setText(result);
			}, 1000);

		},
		// 
		GetClock1: function(){
			var date = new Date();
			window.localStorage.setItem("date", date);
			this.getView().byId("oLabel").setText(window.localStorage.getItem("date"));
		},
		handlePopoverPress: function (oEvent) {
			var oModel = oEvent.getSource().getBindingContext().getProperty().details;
			
			if (!this._oPopover) {
				Fragment.load({
					name: "com.tabletopopover.ZTabletoPopover.view.Fragments.Popover",
					controller: this
				}).then(function (pPopover) {
					this._oPopover = pPopover;
					this.getView().addDependent(this._oPopover);
					
					this._oPopover.setModel(new JSONModel(oModel));
					this._oPopover.openBy(oEvent.getSource());
				}.bind(this));
			} else {
				this._oPopover.openBy(oEvent.getSource());
			}
		
			// var opersonalfrag = sap.ui.xmlfragment("com.tabletopopover.ZTabletoPopover.view.Fragments.Popover", this);
			// this.getView().addDependent(opersonalfrag);
			// opersonalfrag.open();
			//var oModel = oEvent.getSource().getBindingContext().getProperty().details;
			//this.oEmployeeFrag.setModel(new JSONModel(oModel));
			

		}
	});
});