sap.ui.define([
	"com/tabletopopover/ZTabletoPopover/test/unit/controller/Home.controller"
], function () {
	"use strict";
});