sap.ui.define([
	"com/myfirstapp/ZMyFirstApp/test/unit/controller/Home.controller"
], function () {
	"use strict";
});