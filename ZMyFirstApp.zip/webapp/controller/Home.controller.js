sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast",
	"sap/m/MessageBox"

], function (Controller, MessageToast, MessageBox) {
	"use strict";

	return Controller.extend("com.myfirstapp.ZMyFirstApp.controller.Home", {
		onInit: function () {

		},

		onpress: function (Ev) {

			var oName = this.getView().byId("idinput").getValue(),
				oEmp = this.getView().byId("idinput1").getValue(),
				oRbg = this.byId("rbg").getSelectedButton().getText(),
				oLocation = this.getView().byId("idinput2").getValue();
			if (oName !== "" && oEmp !== "" && oLocation !== "") {
				MessageToast.show("Name:" + " " + oName + "\n" + "Roll:" + " " + oEmp + "\n" + "Department:" + " " + oRbg + "\n" +
					"Location:" + " " + oLocation);

			} else {
				MessageBox.error("please enter all the values ");
			}
		}

	});
});