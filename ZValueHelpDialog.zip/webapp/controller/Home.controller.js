sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function (Controller, JSONModel) {
	"use strict";

	return Controller.extend("com.valuehelpdialog.ZValueHelpDialog.controller.Home", {
		onInit: function () {
			// var omodel = this.getOwnerComponent().getModel();
			// this.getView().setModel(omodel);

		},
		onvaluehelp: function () {
			var obj = [{
				name: "Gourab"
			}, {
				name: "sourav"
			}, {
				name: "arnab"
			}, {
				name: "rick"
			}];
			var oModel = new JSONModel();
			oModel.setData(obj);
			var opersonalfrag = sap.ui.xmlfragment("com.valuehelpdialog.ZValueHelpDialog.view.Fragments.name", this);
			opersonalfrag.open();
			sap.ui.getCore().byId("namedialog").setModel(oModel);
			

		}
	});
});