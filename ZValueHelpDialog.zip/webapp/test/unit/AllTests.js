sap.ui.define([
	"com/valuehelpdialog/ZValueHelpDialog/test/unit/controller/Home.controller"
], function () {
	"use strict";
});