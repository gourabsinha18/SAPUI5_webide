sap.ui.define([
	"com/arraybinding/ZArrayBinding/test/unit/controller/home.controller"
], function () {
	"use strict";
});