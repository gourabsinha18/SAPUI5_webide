sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("com.arraybinding.ZArrayBinding.controller.home", {
		onInit: function () {
			var collection = [{
				name: "GOURAB",
				city: "berhampore",
				street: "nilmoni lane",
				country: "india"
			}, {
				name: "sOURAv",
				city: "howrah",
				street: "n.b.lane",
				country: "india"
			}, {
				name: "dip",
				city: "kolkata",
				street: "newyork lane",
				country: "india"
			}, {
				name: "rony",
				city: "berlin",
				street: "harish chandra street ",
				country: "india"
			}];
			var ajsonmodel = new sap.ui.model.json.JSONModel();
			ajsonmodel.setData(collection);
			this.byId("idProductsTable").setModel(ajsonmodel);

		},
		onselect: function (event) {
			var selectedrow = event.getSource().getBindingContext().getObject();
			//var selectedrow = event.getSource().getSelectedContexts()[0].getObject();
			//var myJSON = JSON.stringify(selectedrow);
			//sap.m.MessageToast.show(myJSON);

			var ajsonmodel = new sap.ui.model.json.JSONModel();
			ajsonmodel.setData(selectedrow);
			this.getView().byId("SimpleFormDisplay354").setModel(ajsonmodel);

		}
	});
});