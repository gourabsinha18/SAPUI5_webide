sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"

], function (Controller, JSONModel) {
	"use strict";

	return Controller.extend("com.tablenlist.ZTableNList.controller.Home", {
		onInit: function () {

		},
		onLoadTable: function (Ev) {
			var omodel = this.getOwnerComponent().getModel("data");
			this.getView().byId("idlist").setModel(omodel);
			this.getView().byId("idProductsTable").setModel(omodel);
			if (Ev.getSource().getText() === "Show Table") {
				Ev.getSource().setText("show List");
				this.getView().byId("idProductsTable").setVisible(true);
				this.getView().byId("idlist").setVisible(false);
			} else {
				Ev.getSource().setText("Show Table");
				this.getView().byId("idProductsTable").setVisible(false);
				this.getView().byId("idlist").setVisible(true);
			}

		},
		onLoadList: function () {

			this.getView().byId("idlist").setVisible(true);
			this.getView().byId("idProductsTable").setVisible(false);
		},

		onClear: function () {
			this.getView().byId("idlist").setModel(new JSONModel());
			this.getView().byId("idProductsTable").setModel(new JSONModel());
			// var arr=[];
			// var ajsonmodel = new sap.ui.model.json.JSONModel();
			// ajsonmodel.setData(arr);
			// this.byId("idProductsTable").setModel(ajsonmodel);
			// this.byId("idlist").setModel(ajsonmodel);

		}
	});
});