sap.ui.define([
	"com/tablenlist/ZTableNList/test/unit/controller/Home.controller"
], function () {
	"use strict";
});