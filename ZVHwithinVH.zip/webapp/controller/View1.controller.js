sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("com.vhwithinvh.ZVHwithinVH.controller.View1", {
		onInit: function () {

		},
		onValueHelpRequest: function() {
			
			
			
			
		}
		
	});
});