sap.ui.define([
	"com/navcontainer/ZNavContainer/test/unit/controller/View1.controller"
], function () {
	"use strict";
});