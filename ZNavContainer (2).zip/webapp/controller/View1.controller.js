sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("com.navcontainer.ZNavContainer.controller.View1", {
		onInit: function () {

		},
		onCBselect: function (Ev) {
			var selecteditem = Ev.getSource().getSelectedItem().getBindingContext().getObject();
			var arr = [];
			arr.push(selecteditem);
			var json=new sap.ui.model.json.JSONModel();
			json.setData(arr);
			this.getView().byId("idProductsTable").setModel(json);
			
			var ajsonmodel = new sap.ui.model.json.JSONModel();
			ajsonmodel.setData(selecteditem);
			this.byId("sform").setModel(ajsonmodel);
			
			this.getView().byId("navcon").setVisible(true);

		},
		Onchange: function (Ev) {
			var tab = this.getView().byId("table");
			var form = this.getView().byId("form");
			this.navcon = this.getView().byId("navcon");
			var selectedbtn = Ev.getSource().getSelectedKey();
			if (selectedbtn === "table") {
				this.navcon.to(tab.getId(), "flip");

			} else {
				this.navcon.to(form.getId(), "flip");

			}
			
		},
		showform: function(){
			var form = this.getView().byId("form");
			this.getView().byId("navcon").to(form.getId(), "fade");
		}
		
		
	});
});