sap.ui.define(function () {
	"use strict";

	var Formatter = {
		scoreformat: function (Sval) {
			var todayDate = new Date();
			var reldate = new Date(Sval);
			var day = (todayDate.getTime() - reldate.getTime())/(1000 * 3600 * 24);
			if (day > 60 && day <= 150 ) {
				return "#ff0000"; //red
			}
			if (day <= 30) {
				return "#00ff00";//green
			}
			if (day > 30 && day <= 60) {
				return "#ffff00";//yellow
			}else {
				return "#000066";//blue
			}
		}

	};

	return Formatter;

}, /* bExport= */ true);