sap.ui.define([
	"com/formatterexp/ZFormatterExp/test/unit/controller/View1.controller"
], function () {
	"use strict";
});