sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device"
], function (JSONModel, Device) {
	"use strict";

	return {

		createDeviceModel: function () {
			var oModel = new JSONModel(Device);
			oModel.setDefaultBindingMode("OneWay");
			return oModel;
		},
			CheckModel: function () {
				var obj ={Flag:true};
			var oModel = new JSONModel(obj);
			oModel.setDefaultBindingMode("OneWay");
			return oModel;
		}


	};
});