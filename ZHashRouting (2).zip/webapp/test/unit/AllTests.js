sap.ui.define([
	"com/hrouting/ZHashRouting/test/unit/controller/View1.controller"
], function () {
	"use strict";
});