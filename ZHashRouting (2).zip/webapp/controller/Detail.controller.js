sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function (Controller, JSONModel) {
	"use strict";

	return Controller.extend("com.hrouting.ZHashRouting.controller.Detail", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.abcd.Zabcd.view.Detail
		 */
		onBack: function () {
			this.getOwnerComponent().getRouter().navTo("RouteView1");
		},
		onInit: function () {

			this.getOwnerComponent().getRouter().getRoute("RouteDetail").attachMatched(this._onRouteMatched, this);

		},
		_onRouteMatched: function (Ev) {

			var oView = this.getView(),
				oArgs = Ev.getParameter("arguments"),
				oPath = "/Selectionmodel/" + oArgs.Gfk + "";
				if(oArgs.checkkey==="D"){
					
					this.getOwnerComponent().getModel("CheckFlag").setProperty("/Flag",false);
					this.onDefaultDialogPress();
				}else{
						this.getOwnerComponent().getModel("CheckFlag").setProperty("/Flag",true);
				}
			oView.bindElement({
				path: oPath,
				events: {
					DataRequested: function (oResponse) {
						oView.setBusy(true);
					},
					DataReceived: function (oResponse) {
						oView.setBusy(false);
					}
				}

			});
			this.OnTabchange();

			// var obj = this.getOwnerComponent().getModel().getData().ProductCollection[oArgs.Gfk];
			// oView.setModel(new JSONModel(obj), "DetailFormModel");

			// var GlobalObj = sap.ui.getCore().getModel("HeaderModel").getData();

			// this.getView().setModel(new JSONModel(GlobalObj),"DetailFormModel");
		},
		OnTabchange: function (ev) {
				if (ev === undefined) {
					var key = this.getView().byId("idIconTabBarMulti").getSelectedKey();
				} else {
					key = ev.getParameter("selectedKey");
				}

				if (key === "Key1") {

					var obj = this.getView().getBindingContext().getProperty("details");
					// this.getView().byId("idProductsTable").setModel(new JSONModel({
					// 	details: obj
					// }));
					this.getView().byId("idProductsTable").setModel(new JSONModel(obj));
				}

			},
			onDefaultDialogPress: function () {
			var that = this;
			var oInput = new sap.m.Input({
				placeholder: "Enter No.",
				showValueHelp: true,
				valueHelpRequest: function () {
					that.opressvh();
				}

			});
			if (!this.oDefaultDialog) {
				this.oDefaultDialog = new sap.m.Dialog({
					title: "Please Confirm",

					beginButton: new sap.m.Button({
						type: sap.m.ButtonType.Emphasized,
						text: "OK",
						press: function () {
							this.oDefaultDialog.close();
						}.bind(this)
					}),
					endButton: new sap.m.Button({
						text: "Close",
						press: function () {
							this.oDefaultDialog.close();
						}.bind(this)
					})
				});
				
				this.oDefaultDialog.addContent(oInput);
				// to get access to the controller's model
				this.getView().addDependent(this.oDefaultDialog);
			}
			
			this.oDefaultDialog.open();
		}
			/**
			 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
			 * (NOT before the first rendering! onInit() is used for that one!).
			 * @memberOf com.abcd.Zabcd.view.Detail
			 */
			//	onBeforeRendering: function() {
			//
			//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.abcd.Zabcd.view.Detail
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.abcd.Zabcd.view.Detail
		 */
		//	onExit: function() {
		//
		//	}

	});

});