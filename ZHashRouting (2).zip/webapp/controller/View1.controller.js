sap.ui.define([
	"sap/ui/core/mvc/Controller",
	'sap/ui/core/Fragment',
	"sap/m/Dialog",
	'sap/ui/model/json/JSONModel'
], function (Controller, Fragment, Dialog, JSONModel) {
	"use strict";

	return Controller.extend("com.hrouting.ZHashRouting.controller.View1", {
		onInit: function () {

		},
		_onRowPress: function (Ev) {

			var oKey = Ev.getSource().getBindingContext().getProperty("Key");
			var oPath = this.oCtx.getProperty("key");
			// sap.ui.getCore().setModel(new JSONModel(oItem), "HeaderModel");
			this.getOwnerComponent().getRouter().navTo("RouteDetail", {
				Gfk: oPath,
				checkkey: oKey
			});

		},
		handlePopoverPress: function (oEvent) {
			this.oCtx = oEvent.getSource().getBindingContext();
			var arr = [{
				text: "Display",
				Key: "D"
			}, {
				text: "Edit",
				Key: "E"
			}];

			var oButton = oEvent.getSource();

			// create popover
			if (!this._oPopover) {
				Fragment.load({
					name: "com.hrouting.ZHashRouting.view.Fragments.Popover",
					controller: this
				}).then(function (pPopover) {
					this._oPopover = pPopover;
					this.getView().addDependent(this._oPopover);
					this._oPopover.setModel(new JSONModel(arr));
					this._oPopover.openBy(oButton);
				}.bind(this));
			} else {
				this._oPopover.openBy(oButton);
			}
		}
		

	});
});