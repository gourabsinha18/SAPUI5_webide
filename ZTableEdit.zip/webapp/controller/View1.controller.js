sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("com.tableedit.ZTableEdit.controller.View1", {
		onInit: function () {

		},

		onpressedit: function (oEvent) {
			// this.getView().byId("idedit").setVisible(false);

			var oItem = oEvent.getSource().getParent();
			oItem.getItems()[1].setVisible(true);
			oItem.getItems()[2].setVisible(true);
			oItem.getItems()[0].setVisible(false);
			var cell = oEvent.getSource().getParent().getParent().getCells();
			cell.shift();
			//var oTable = this.getView().byId("idProductsTable");
			//var oIndex = oTable.indexOfItem(oItem);
			//var oModel = this.getView().getModel();
			$(cell).each(function (i) {
				var oEditableCell = cell[i];
				// var oMetaData = oEditableCell.getMetadata();
				// var oElement = oMetaData.getElementName();
				if (oEditableCell instanceof sap.m.VBox) {
					if (oEditableCell.getItems()[0] instanceof sap.m.Input && oEditableCell.getItems()[0].getBindingInfo("value").binding.sPath ===
						"ID") {
						oEditableCell.getItems()[0].setEditable(false);
						//oEditableCell.getItems()[1].setVisible(false);
					} //else if(oEditableCell instanceof sap.m.select){}                               }
				}
				oEditableCell.getItems()[0].setVisible(true);
				oEditableCell.getItems()[1].setVisible(false);

				//oEditableCell.setEditable(oFlag);

			});
			//this.onPress(oItem, true);

		},
		onpresscancel: function (Ev) {
			var oItem = Ev.getSource().getParent();
			this.onPress(oItem, false);
			oItem.getItems()[1].setVisible(false);
			oItem.getItems()[2].setVisible(false);
			oItem.getItems()[0].setVisible(true);
		},
		onPress: function (oItem, oFlag) {
			var oEditableCells = oItem.getParent().getCells();
			$(oEditableCells).each(function (i) {
				var oEditableCell = oEditableCells[i];
				var oMetaData = oEditableCell.getMetadata();
				var oElement = oMetaData.getElementName();
				if (oElement === "sap.m.VBox") {
					oEditableCell.getItems()[0].setEditable(oFlag);
				}
				
			});
		},
		onDelete: function () {
			var oTable = this.getView().byId("idProductsTable");
			if (oTable.getMode() === "SingleSelectMaster") {
				oTable.setMode("SingleSelect");
			} else {
				var ID = oTable.getSelectedItem().getBindingContext().getObject("ID");
				this.onOdataDelete(ID);
				oTable.setMode("None");

			}
		},
		onOdataDelete: function (ID) {
			var oModel = this.getView().getModel();

			oModel.remove("/Products(" + ID + ")", {
				method: "DELETE",
				success: function (data) {
					sap.m.MessageToast.show("Item Deleted");
				},
				error: function (e) {
					sap.m.MessageToast.show("error");
				}
			});
		},
		onAdd: function () {
			var oTable = this.getView().byId("idProductsTable");
			var columnListItemNewLine = new sap.m.ColumnListItem({
				cells: [
					// add created controls to item
					new sap.m.Button({
						type: "Transparent",
						icon: "sap-icon://save",
						press: [this.onsave, this]

					}), new sap.m.Input({
						value: "{ID}",
						type: "Number",
						placeholder: "Enter Product ID"
					}), new sap.m.Input({
						value: "{Name}",
						type: "Text",
						placeholder: "Enter name"
					}), new sap.m.Input({
						value: "{Description}",
						type: "Text",
						placeholder: "Enter Description"
					}),
					new sap.m.DateTimePicker({
						value: "{ReleaseDate}",

						placeholder: "ReleaseDate"
					}),
					new sap.m.DateTimePicker({
						value: "{DiscontinuedDate}",

						placeholder: "DiscontinuedDate"
					}),
					new sap.m.Input({
						value: "{Rating}",
						type: "Number",
						placeholder: "Enter Rating"
					}),
					new sap.m.Input({
						value: "{Price}",
						type: "Number",
						placeholder: "Enter price"
					})
				]
			});
			oTable.addItem(columnListItemNewLine);

		},
		onModify: function (Ev) {
			var opath = "/Products";
			var oModel = this.getOwnerComponent().getModel();
			var obj = Ev.getSource().getParent().getParent().getCells();
			var entry = {
				"ID" : obj[1].getItems()[0].getValue(),
				"Name" : obj[2].getItems()[0]._getSelectedItemText(),
				"Description" :obj[3].getItems()[0]._getSelectedItemText(),
				"ReleaseDate" :obj[4].getItems()[0].getValue(),
				"DiscontinuedDate" :obj[6].getItems()[0].getValue(),
				"Rating" :obj[5].getItems()[0].getValue(),
				"Price" :obj[7].getItems()[0].getValue()

			};
			var oItem = Ev.getSource().getParent();
			this.onPress(oItem, false);
			oItem.getItems()[1].setVisible(false);
			oItem.getItems()[2].setVisible(false);
			oItem.getItems()[0].setVisible(true);
			//Ev.getSource().getParent().getParent().getCells()[1].getItems()[0].getValue()
			oModel.create(opath, entry, {
				method: "POST",
				success: function (data) {
					sap.m.MessageToast.show("success");
				},
				error: function (e) {
					sap.m.MessageToast.show("error");
				}
			});
		},
		onsave: function (Ev) {
			var opath = "/Products";
			var oModel = this.getOwnerComponent().getModel();
			var cells = Ev.getSource().getParent().getCells();
			var oEntry = {};
			for (var i = 1; i < cells.length; i++) {
				oEntry[cells[i].getBindingInfo("value").parts[0].path] = cells[i].getValue();

			}
			console.log(oEntry);

			oModel.create(opath, oEntry, {
				method: "POST",
				success: function (data) {
					sap.m.MessageToast.show("success");
				},
				error: function (e) {
					sap.m.MessageToast.show("error");
				}
			});
			var oItem = Ev.getSource();
			cells[0].setIcon("sap-icon://edit");
			this.onPress(oItem, false);
		}
	});
});