sap.ui.define([
	"com/tableedit/ZTableEdit/test/unit/controller/View1.controller"
], function () {
	"use strict";
});