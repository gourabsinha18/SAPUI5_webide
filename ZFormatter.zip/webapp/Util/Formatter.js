sap.ui.define(function() {
	"use strict";

	var Formatter = {
		scoreformat :function(Sval){
			if(Sval>="300"){
				return "Success";
			}
			if(Sval<="300" && Sval>="250"){
				return "Warning";
			}else{
				return "Error";
			}
		}

		
	};

	return Formatter;

}, /* bExport= */ true);