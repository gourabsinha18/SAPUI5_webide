sap.ui.define([
	"com/formatter/ZFormatter/test/unit/controller/View1.controller"
], function () {
	"use strict";
});