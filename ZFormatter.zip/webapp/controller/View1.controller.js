sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function (Controller, JSONModel) {
	"use strict";

	return Controller.extend("com.formatter.ZFormatter.controller.View1", {
		onInit: function () {
			var arr = [{
				"Name": "Virat Kohli",
				"Team": "DD",
				"City": "Delhi",
				"Score": "300"
			}, {
				"Name": "Sourav",
				"Team": "KKR",
				"City": "Kolkata",
				"Score": "250"
			}, {
				"Name": "GOURAB",
				"Team": "RCB",
				"City": "Bangalore",
				"Score": "200"
			}, {
				"Name": "Indranil",
				"Team": "SRH",
				"City": "Hyderabad",
				"Score": "326"
			}, {
				"Name": "Anubhav",
				"Team": "CSK",
				"City": "Chennai",
				"Score": "260"
			}, {
				"Name": "Ishan",
				"Team": "TT",
				"City": "Tamilnadu",
				"Score": "350"
			}];
			this.getView().byId("idProductsTable").setModel(new JSONModel(arr));

		}
	});
});