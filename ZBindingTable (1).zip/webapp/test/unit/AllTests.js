sap.ui.define([
	"com/bindingtable/ZBindingTable/test/unit/controller/Home.controller"
], function () {
	"use strict";
});